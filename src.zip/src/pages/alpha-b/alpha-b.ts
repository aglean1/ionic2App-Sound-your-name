import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {NativeAudio} from 'ionic-native';
import { MediaPlugin } from 'ionic-native';
import { ViewChild } from '@angular/core';
import {Shake} from 'ionic-native';
import {Vibration } from 'ionic-native';
import {TextToSpeech} from 'ionic-native';
import {Sounds} from "../../providers/sounds";

/*
  Generated class for the AlphaB page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-alpha-b',
  templateUrl: 'alpha-b.html'
})
export class AlphaBPage {
    count:any = 0;
    alphaSounds: any;
    status="false";
    name: string = "";
       alphab=0;
    public alphaarr =[];
   //public alphaarr2 =["A","B","C","D","E","F","G","H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R","S", "T", "U", "V", "W", "X", "Y", "Z"];
  constructor(public navCtrl: NavController,  private newProvider:Sounds) {
      //var file = new MediaPlugin('GuitarChord-A_64kb.m3u');

  }

    ngAfterViewInit(){
        this.newProvider.load().then((data) =>{
            this.alphaSounds = data.alphaSounds;
            console.log("This"+ data.alphaSounds,data.alphaSounds)
        });
    }


  ionViewDidLoad() {
    console.log('Hello AlphaBPage Page');
  }

    dummy():void{

    }

    public reg:any;
    clearName():void {

        let nameArray = this.name.split('');
        for(let i = 0 ; i < nameArray.length; i++){
            this.reg =document.getElementById(nameArray[i]);
            console.log( "The array value" + nameArray[i]);
            this.reg.style.backgroundColor = "transparent";
            console.log("The element is" + this.reg);
        }



        this.name = "";

    }


    sounding(nameArray,i){
        NativeAudio.preloadSimple(nameArray[i], "assets/soundFiles/" + nameArray[i] + ".wav");
        //NativeAudio.preloadSimple('uniqueId1', 'Test.mp3');
        NativeAudio.play(nameArray[i], () => console.log('Id1 is done playing'));
    }
    soundName(){

        let nameArray = this.name.split('');
        for(let i = 0 ; i < nameArray.length; i++) {
            setTimeout(this.sounding(nameArray,i),5000);
            //this.count+=1000;

        }

    }

    playName(){
        TextToSpeech.speak(this.name + ',sounds like')
            .then(() => console.log('Success'))
            .catch((reason: any) => console.log(reason));
            setTimeout(this.soundName(),10000);
        /*
        let nameArray = this.name.split('');
        for(let i = 0 ; i < nameArray.length; i++){
            NativeAudio.preloadSimple(nameArray[i],"assets/soundFiles/" + nameArray[i] + ".wav");
            //NativeAudio.preloadSimple('uniqueId1', 'Test.mp3');
            NativeAudio.play(nameArray[i],() => console.log('uniqueId1 is done playing'));
            //NativeAudio.play(nameArray[i],"assets/soundFiles/" + nameArray[i] + ".wav");
        }
        */

    }






    select_click(letter,event): void
   {

       this.name = this.name + letter;
       //debugger;
       event.currentTarget.style.backgroundColor = "#f5f443";
       this.status="true";

       Vibration.vibrate(200);



       //watch.unsubscribe();
     // TextToSpeech.speak(letter)
          // .then(() => console.log('Success'))
          // .catch((reason: any) => console.log(reason));
       NativeAudio.preloadSimple(letter, "assets/soundFiles/" + letter + ".wav");
       NativeAudio.play(letter, () => console.log('uniqueId1 is done playing'));

       let watch = Shake.startWatch(40).subscribe(() => {
           this.clearName();
           NativeAudio.preloadSimple("Tpaper", "assets/soundFiles/Tpaper.wav");
           NativeAudio.play("Tpaper", () => console.log('uniqueId1 is done playing'));

      });


     // var element =document.getElementById(clicked);
      //var inputBox =document.getElementById("inputBox");
     /* var allinput =" ";
          event.currentTarget.style.backgroundColor = "#f5f443";
          this.alphaarr[this.alphab] = letter;
          this.alphab++;
       for( var x=0; x<this.alphaarr.length; x++ ) {
           allinput = allinput + this.alphaarr[x];
       }
          //inputBox.innerHTML = allinput;
*/

   }


}
